n = int(input('Digite o numero:'))
soma = 0
while n != 0:
    soma += n
    n = int(input('Digite o numero:'))
print(soma)

print('Fim')