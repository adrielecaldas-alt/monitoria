n = int(input('Digite um numero:')) # 5
i=0
while i <= n: # 0 < = 5
    if i % 2 == 0: # 0 == 0
        print(i)
    i += 1